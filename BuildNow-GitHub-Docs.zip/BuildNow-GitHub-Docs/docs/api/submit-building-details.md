# Submit Building Details

Submit building permission/application details to the BuildNow API.

## Endpoint

| Property | Value |
|---|---|
| HTTP method | `POST` |
| URL | `https://uat-tgrerait.aptonline.in:7443/RERAAPI/api/Buildnow/submitbuildingdetails` |
| Content type | `application/json` |

## Request headers

| Header | Value |
|---|---|
| `x-api-key` | `YOUR_BUILDNOW_API_KEY` |
| `Content-Type` | `application/json` |

Set `x-api-key` to the API key issued for your environment. Do not commit the actual key to this repository.

## Request body

The request body is JSON. The complete sample payload is available in [`examples/submit-building-details.request.json`](../../examples/submit-building-details.request.json).

```json
{
  "request_id": "c7e2a91d-8f4b-4d2a-b1a9-9e04c1122335fgh2215441",
  "application_id": "d9f4b820-1c5a-4e91-9f33-aa556677fghf44155088991",
  "file_no": "BUILD/2026/DEF",
  "status": "Approved",
  "authority": "GHMC",
  "project_type": "Building Permission",
  "case_type": "New",
  "plot_use": "Residential",
  "plot_sub_use": "Independent House",
  "application_submission_date": "2025-03-20",
  "owner_details": [
    {
      "name": "Srinivas Reddy",
      "email": "srinivas.reddy@example.com",
      "phone_number": "+919701234567",
      "correspondence_address": "H.No 3-5-112, Ameerpet",
      "pincode": 500016
    },
    {
      "name": "Lakshmi Reddy",
      "email": "lakshmi.reddy@example.com",
      "phone_number": "+919876501234",
      "correspondence_address": "H.No 3-5-112, Ameerpet",
      "pincode": 500016
    }
  ],
  "site_details": {
    "land_use": "Residential",
    "site_area_in_sq_mts": 600.0,
    "net_site_area_in_sq_mts": 540.0,
    "road_effected_area_in_sq_mts": 18.0,
    "nalla_effected_area_in_sq_mts": 6.5,
    "present_market_value_per_sq_yd_in_inr": 48000.0
  },
  "site_address": {
    "district": "Hyderabad",
    "mandal": "Ameerpet",
    "municipality_corp_gp": "GHMC",
    "village": "Ameerpet",
    "plot_number": "Plot 18",
    "house_or_door_number": "H.No 3-5-112",
    "street_or_road": "Sanjeeva Reddy Nagar Road",
    "locality": "SR Nagar",
    "survey_details": [
      {
        "survey_no": "2345",
        "extent_in_sq_mts": 150.0
      }
    ],
    "geo_location": [
      {
        "lat": 17.4375,
        "long": 78.4483
      },
      {
        "lat": 17.4379,
        "long": 78.4489
      }
    ]
  },
  "ltp_details": {
    "name": "Prakash Verma",
    "licence_no": "LTP-556677",
    "phone_number": "+919812009988",
    "email": "prakash.verma@example.com",
    "address": "Architects Lane, Begumpet"
  },
  "builder_details": {
    "name": "Sri Sai Builders",
    "licence_no": "BLD-778899",
    "phone_number": "+919845667788",
    "email": "contact@srisaibuilders.com",
    "address": "Begumpet, Hyderabad"
  },
  "structural_engineer_details": {
    "name": "Rajesh Mehta",
    "licence_no": "SE-445566",
    "phone_number": "+919833445566",
    "email": "rajesh.mehta@example.com",
    "address": "Punjagutta, Hyderabad"
  },
  "documents": {
    "legal_proof_of_ownership": [
      "<https://example.com/docs/ownership_sr.pdf>"
    ],
    "encumbrance_certificate": [
      "<https://example.com/docs/ec_sr.pdf>"
    ],
    "fire_noc": [
      "<https://buildnow.telangana.gov.in/docs/fire_noc.pdf>"
    ],
    "mortgage_deed": [
      "<https://buildnow.telangana.gov.in/docs/mortgage_deed.pdf>"
    ],
    "risk_insurance_policy": [
      "<https://buildnow.telangana.gov.in/docs/risk_insurance_policy.pdf>"
    ],
    "other_documents": [
      "<https://buildnow.telangana.gov.in/docs/other_documents.pdf>"
    ],
    "ownership_and_legal": {
      "land_conversion_certificate": [
        "<https://buildnow.telangana.gov.in/docs/land_conversion_certificate.pdf>"
      ],
      "market_value_certificate": [
        "<https://buildnow.telangana.gov.in/docs/market_value_certificate.pdf>"
      ],
      "common_affidavit": [
        "<https://buildnow.telangana.gov.in/docs/common_affidavit.pdf>"
      ],
      "revenue_sketch": [
        "<https://buildnow.telangana.gov.in/docs/revenue_sketch.pdf>"
      ],
      "pattadar_passbook": [
        "<https://buildnow.telangana.gov.in/docs/pattadar_passbook.pdf>"
      ],
      "orc": [
        "<https://buildnow.telangana.gov.in/docs/orc.pdf>"
      ]
    },
    "vicinity_to_restricted_area": {
      "water_body_within_200m": [
        "<https://buildnow.telangana.gov.in/docs/water_body_within_200m.pdf>"
      ],
      "prohibited_land": [
        "<https://buildnow.telangana.gov.in/docs/prohibited_land.pdf>"
      ],
      "nala_conversion": [
        "<https://buildnow.telangana.gov.in/docs/nala_conversion.pdf>"
      ],
      "air_funnel_zone": [
        "<https://buildnow.telangana.gov.in/docs/air_funnel_zone.pdf>"
      ],
      "defence_boundary_within_10m": [
        "<https://buildnow.telangana.gov.in/docs/defence_boundary_within_10m.pdf>"
      ],
      "oil_gas_pipeline": [
        "<https://buildnow.telangana.gov.in/docs/oil_gas_pipeline.pdf>"
      ],
      "railway_boundary_within_30m": [
        "<https://buildnow.telangana.gov.in/docs/railway_boundary_within_30m.pdf>"
      ],
      "protected_monument_within_200m": [
        "<https://buildnow.telangana.gov.in/docs/protected_monument_within_200m.pdf>"
      ],
      "water_pipeline_within_100m": [
        "<https://buildnow.telangana.gov.in/docs/water_pipeline_within_100m.pdf>"
      ],
      "religious_structure_within_100m": [
        "<https://buildnow.telangana.gov.in/docs/religious_structure_within_100m.pdf>"
      ],
      "military_airport_within_1000m": [
        "<https://buildnow.telangana.gov.in/docs/military_airport_within_1000m.pdf>"
      ],
      "court_case_on_title": [
        "<https://buildnow.telangana.gov.in/docs/court_case_on_title.pdf>"
      ],
      "scheduled_area_or_tree_felling": [
        "<https://buildnow.telangana.gov.in/docs/scheduled_area_or_tree_felling.pdf>"
      ]
    },
    "department_nocs": {
      "fire": [
        "<https://buildnow.telangana.gov.in/docs/fire.pdf>"
      ],
      "irrigation": [
        "<https://buildnow.telangana.gov.in/docs/irrigation.pdf>"
      ],
      "revenue": [
        "<https://buildnow.telangana.gov.in/docs/revenue.pdf>"
      ],
      "title": [
        "<https://buildnow.telangana.gov.in/docs/title.pdf>"
      ]
    }
  },
  "permit_details": {
    "permit_no": "2026/BP/6784290",
    "permit_date": "2025-04-05",
    "due_date_for_work_commencement": "2025-05-10",
    "due_date_for_work_completion": "2029-04-05",
    "proceedings_document": [
      {
        "document_name": "Building Permit Order - HMDA Proceedings",
        "url": "<https://buildnow.telangana.gov.in/docs/building_permit_order_hmda_proceedings.pdf>"
      },
      {
        "document_name": "Mortgage Letter",
        "url": "<https://buildnow.telangana.gov.in/docs/mortgage_letter.pdf>"
      }
    ],
    "drawing_pdf": [
      "<https://example.com/docs/drawing_sr.pdf>"
    ],
    "scrutiny_report": [
      "<https://buildnow.telangana.gov.in/docs/scrutiny_report.pdf>"
    ]
  },
  "proposed_building_permission_details": {
    "builtup_area_in_sq_mts": 520.75,
    "mortage_area_in_sq_mts": 60.0,
    "no_of_RWH": 4,
    "buildings_details": [
      {
        "building_name": "Main Block",
        "building_type": "Residential",
        "building_height_in_mts": 12.0,
        "building_use": "Independent House",
        "no_of_dwelling_units": 1,
        "net_building_residential_builtup_area_in_sq_mts": 480.0,
        "net_building_commercial_builtup_area_in_sq_mts": 0.0,
        "net_building_total_parking_area": 60.0,
        "mortgage_area_in_sq_mts": 60.0,
        "mortgage_tenemant_names": "State Bank of India",
        "floors_details": [
          {
            "floor_no": 2,
            "floor_name": "Residential Floors",
            "floor_type": "Residential",
            "floor_height_in_mts": 3.0,
            "net_floor_residential_builtup_area_in_sq_mts": 160.0,
            "net_floor_commercial_builtup_area_in_sq_mts": 0.0
          }
        ]
      }
    ]
  },
  "proposed_layout_with_open_plot_details": {
    "open_space_area_in_sq_mts": 180.0,
    "social_infrastructure_area_in_sq_mts": 40.0,
    "plotted_area_in_sq_mts": 250.0,
    "roads_area_in_sq_mts": 90.0,
    "sub_plots_details": [
      {
        "sub_plot_name": "OP-2",
        "sub_plot_area_in_sq_mts": 180.0,
        "is_mortgaged": false
      }
    ]
  },
  "proposed_layout_with_housing_and_gated_community_details": {
    "open_space_area_in_sq_mts": 210.0,
    "social_infrastructure_area_in_sq_mts": 55.0,
    "plotted_area_in_sq_mts": 300.0,
    "roads_area_in_sq_mts": 110.0,
    "utilities_area_in_sq_mts": 35.0,
    "sub_plots_details": [
      {
        "sub_plot_name": "GC-Plot-2",
        "sub_plot_area_in_sq_mts": 260.0,
        "building_details": {
          "building_name": "Garden Residency",
          "building_height_in_mts": 15.0,
          "building_use": "Residential",
          "net_building_residential_builtup_area_in_sq_mts": 650.0,
          "net_building_commercial_builtup_area_in_sq_mts": 0.0,
          "net_building_total_parking_area": 180.0,
          "is_mortgaged": true,
          "floors": [
            {
              "floor_number": 2,
              "floor_name": "Second Floor",
              "floor_type": "Residential",
              "floor_height_in_mts": 3.0,
              "net_floor_residential_builtup_area_in_sq_mts": 130.0,
              "net_floor_commercial_builtup_area_in_sq_mts": 0.0
            }
          ]
        }
      }
    ]
  },
  "proposed_layout_with_housing_and_without_gated_community_details": {
    "open_space_area_in_sq_mts": 190.0,
    "social_infrastructure_area_in_sq_mts": 35.0,
    "plotted_area_in_sq_mts": 270.0,
    "roads_area_in_sq_mts": 100.0,
    "utilities_area_in_sq_mts": 30.0,
    "sub_plots_details": [
      {
        "sub_plot_name": "NGC-Plot-2",
        "sub_plot_area_in_sq_mts": 240.0,
        "building_details": {
          "building_name": "Duplex Homes",
          "building_height_in_mts": 9.5,
          "building_use": "Residential",
          "net_building_residential_builtup_area_in_sq_mts": 360.0,
          "net_building_commercial_builtup_area_in_sq_mts": 0.0,
          "net_building_total_parking_area": 80.0,
          "is_mortgaged": false,
          "floors": [
            {
              "floor_number": 1,
              "floor_name": "First Floor",
              "floor_type": "Residential",
              "floor_height_in_mts": 2.9,
              "net_floor_residential_builtup_area_in_sq_mts": 180.0,
              "net_floor_commercial_builtup_area_in_sq_mts": 0.0
            }
          ]
        }
      }
    ]
  }
}
```

## Success response

```json
{
  "status": "success",
  "request_id": "c7e2a91d-8f4b-4d2a-b1a9-9e04c1122335fgh2215441"
}
```

## Notes

- `request_id` must be unique for every application submission.
- The supplied source document does not define field-level requiredness, validation constraints, or error response formats. Confirm those details with the API provider before treating the sample as a complete contract.
