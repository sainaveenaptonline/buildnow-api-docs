# BuildNow API Documentation

Welcome to the BuildNow API documentation.

Use the [Submit Building Details](api/submit-building-details.md) reference for endpoint details, headers, request payload, and success response.
