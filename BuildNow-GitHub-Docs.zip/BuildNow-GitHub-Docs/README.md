# BuildNow API Documentation

GitHub-ready documentation for the BuildNow building-details submission API.

## API

- **Name:** Submit Building Details
- **Method:** `POST`
- **Endpoint:** `https://uat-tgrerait.aptonline.in:7443/RERAAPI/api/Buildnow/submitbuildingdetails`
- **Content-Type:** `application/json`

## Documentation

- [Submit Building Details – API reference](docs/api/submit-building-details.md)
- [Sample request JSON](examples/submit-building-details.request.json)
- [Sample success response JSON](examples/submit-building-details.success.json)

## Publish with GitHub Pages

This repository is configured for [MkDocs](https://www.mkdocs.org/) and GitHub Pages.

1. Create a GitHub repository (for example, `buildnow-api-docs`).
2. Upload/push the contents of this folder to the repository's root.
3. In GitHub, open **Settings → Pages** and select **GitHub Actions** as the build/deployment source.
4. Push to the `main` branch. The included workflow builds and deploys the documentation.
5. The published site URL will appear under **Settings → Pages**.

## API key security

The source Word document contained an API key. It is deliberately not included in this repository. Configure the real key as a GitHub Actions secret or in your API client/runtime configuration, and rotate the exposed key before use. Never commit API keys to Git.

The request example uses the placeholder `YOUR_BUILDNOW_API_KEY`.

## Source and scope

The endpoint, sample payload, success response, and unique `request_id` note are based on the supplied BuildNow API document. Field descriptions and validation rules were not specified in that source and are therefore not invented here.
